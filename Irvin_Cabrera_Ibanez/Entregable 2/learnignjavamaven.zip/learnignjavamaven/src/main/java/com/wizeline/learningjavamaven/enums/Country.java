package com.wizeline.learningjavamaven.enums;

public enum Country {
  US, MX, FR
}

