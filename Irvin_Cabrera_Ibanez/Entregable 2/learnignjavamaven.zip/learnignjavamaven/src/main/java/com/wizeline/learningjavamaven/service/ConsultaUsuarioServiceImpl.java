package com.wizeline.learningjavamaven.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wizeline.learningjavamaven.LearningJavaApplication;
import com.wizeline.learningjavamaven.model.detalle.UserDescription;
import com.wizeline.learningjavamaven.utils.exceptions.ExcepcionUnica;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.TimeZone;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@Service
public class ConsultaUsuarioServiceImpl implements ConsultaUsuarioService {

  private static final Logger LOGGER = Logger.getLogger(LearningJavaApplication.class.getName());

  RestTemplate restTemplate = new RestTemplate();

  @Autowired
  private AsyncTaskExecutor lowPriorityTaskExecutor;

  public List<UserDescription> consultaSuccess() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
    try {
      List<UserDescription> users = mapper.readValue(peticion(), new TypeReference<List<UserDescription>>() {
      });
      return users;
    } catch (JsonProcessingException e) {
      throw new ExcepcionUnica(403, Collections.singletonList(e.getMessage()), HttpStatus.CONFLICT);
    }
  }

  public List<UserDescription> consultaError() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.setTimeZone(TimeZone.getTimeZone("Mexico/General"));
    try {
      List<UserDescription> users = mapper.readValue(peticion(), new TypeReference<List<UserDescription>>() {
      });
      return users;
    } catch (JsonProcessingException e) {
      throw new ExcepcionUnica(403, Collections.singletonList("Error desencriptado"), HttpStatus.CONFLICT);
    }
  }

  private String peticion() {
    ResponseEntity<String> response = restTemplate.exchange("https://jsonplaceholder.typicode.com/users", HttpMethod.GET, null, String.class);
    return response.getBody();
  }

  public List<UserDescription> filtrado() {
    List<UserDescription> userList = consultaSuccess();
    ValidarCodigoSimple validarCodigoSimple = new ValidarCodigoSimple();
    return userList.stream().map(user -> {
      if (validarCodigoSimple.validarCodigo(user.getAddress())) {
        Instant inicioDeEjecucion = Instant.now();
        NotificacionThread notificacionThread = new NotificacionThread(user, inicioDeEjecucion);
        notificacionThread.start();
        return user;
      }
      return null;
    }).filter(Objects::nonNull).collect(Collectors.toList());
  }
}
