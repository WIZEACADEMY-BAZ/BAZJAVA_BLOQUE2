package com.wizeline.learningjavamaven.model;

public class XmlBean {

  private Object data;

  public Object getData() {
    return data;
  }

  public void setData(Object object) {
    this.data = object;
  }
}
