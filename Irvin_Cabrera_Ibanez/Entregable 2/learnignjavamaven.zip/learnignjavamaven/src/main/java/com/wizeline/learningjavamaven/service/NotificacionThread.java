package com.wizeline.learningjavamaven.service;

import com.wizeline.learningjavamaven.model.detalle.UserDescription;

import java.time.Duration;
import java.time.Instant;
import java.util.logging.Logger;

public class NotificacionThread extends Thread {

  private static final Logger LOGGER = Logger.getLogger(NotificacionThread.class.getName());

  UserDescription user;
  Instant inicioDeEjecucion;

  public NotificacionThread(UserDescription user, Instant inicioDeEjecucion) {
    this.user = user;
    this.inicioDeEjecucion = inicioDeEjecucion;
  }

  @Override
  public void run() {
    try {
      // sleep simula el tiempo de respuesta de un servicio
      sleep(1000);
      Instant finalDeEjecucion = Instant.now();
      String total = new String(String.valueOf(Duration.between(inicioDeEjecucion, finalDeEjecucion).toMillis()).concat(" segundos."));
      LOGGER.info("Envio y validación de usuario de notificación de consulta " + user.getName());
      LOGGER.info("Tiempo de envio: ".concat(total));
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
  }
}
