package com.wizeline.learningjavamaven.enums;

public enum AccountType {
  NOMINA, AHORRO, PLATINUM
}
