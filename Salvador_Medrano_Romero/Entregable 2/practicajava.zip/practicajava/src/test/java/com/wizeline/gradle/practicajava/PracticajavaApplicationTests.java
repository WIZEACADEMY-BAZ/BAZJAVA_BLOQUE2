package com.wizeline.gradle.practicajava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticajavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
