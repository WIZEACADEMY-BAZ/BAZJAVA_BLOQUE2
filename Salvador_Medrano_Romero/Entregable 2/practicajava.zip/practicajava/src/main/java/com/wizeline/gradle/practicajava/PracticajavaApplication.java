package com.wizeline.gradle.practicajava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticajavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticajavaApplication.class, args);
	}

}
